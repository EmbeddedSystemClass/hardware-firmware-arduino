//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by GraphTest.rc
//
#define IDD_GRAPHTEST_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDR_GRAPH_CONTEXT_MENU          129
#define IDC_GRAPH_STATIC                1000
#define ID_SHOWDOTS_SHOWDOTS            32771
#define ID_GRAPH_SHOWDOTS               32772
#define ID_GRAPH_RESETZOOM              32773
#define ID_GRAPH_SHOWCURSOR             32774
#define ID_GRAPH_SHOWGRID               32775

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32776
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
